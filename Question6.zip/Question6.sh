#!/bin/bash
echo "Enter network address to scan eg. (192.168.1.0/24)"
read ip_address
nmap -sP $ip_address

